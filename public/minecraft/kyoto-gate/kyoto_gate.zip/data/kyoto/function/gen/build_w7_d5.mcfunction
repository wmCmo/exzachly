# Builds a 7x5 house. Macro args: f (floors), front, roof, seed, rot
# 1) cut terrain out of the volume, 2) stone foundation down to the ground, 3) parts
fill ^-4 ^ ^ ^4 ^13 ^6 air replace #kyoto:diggable
execute unless score #stilt ky.var matches 1 run fill ^-3 ^-2 ^1 ^3 ^-8 ^5 stone_bricks replace #kyoto:fillable
execute if score #stilt ky.var matches 1 run function kyoto:gen/stilts_w7_d5
$place template kyoto:house/body_w7_d5_f$(f) ^-4 ^-1 ^ $(rot)
$place template kyoto:house/interior_w7_d5_f$(f)_$(interior) ^-4 ^-1 ^ $(rot)
$place template kyoto:house/front_w7_d5_f$(f)_$(front) ^-4 ^-1 ^ $(rot)
$execute if score #front ky.var matches 3 run place template kyoto:house/namako_w7_d5 ^-4 ^-1 ^ $(rot)
$execute if score #corner ky.var matches 1 run place template kyoto:house/sidel_w7_d5_f$(f) ^-4 ^-1 ^ $(rot)
$execute if score #corner ky.var matches 2 run place template kyoto:house/sider_w7_d5_f$(f) ^-4 ^-1 ^ $(rot)
$place template kyoto:house/roof_w7_d5_f$(f)_$(roof) ^-4 ^-1 ^ $(rot)
$place template kyoto:house/deco_w7_d5_f$(f) ^-4 ^-1 ^ $(rot) none 0.35 $(seed)
$place template kyoto:house/windows_w7_d5_f$(f)_v$(win) ^-4 ^-1 ^ $(rot)
$fill ^-3 ^ ^1 ^3 ^13 ^5 $(wall) replace white_terracotta
summon marker ^ ^ ^3 {Tags:["ky.house"]}
execute if score #cush ky.var matches 1 positioned ^-1 ^ ^3 run function kyoto:life/cushion
execute if score #cush ky.var matches 1 positioned ^1 ^ ^3 run function kyoto:life/cushion
execute if score #cush ky.var matches 1 positioned ^-1 ^ ^2 run function kyoto:life/cushion
# pots, barrels and the like: only where there is ground to stand on
execute positioned ^-4 ^ ^ run function kyoto:deco/ground
execute positioned ^-3 ^ ^ run function kyoto:deco/ground
execute positioned ^-2 ^ ^ run function kyoto:deco/ground
execute positioned ^-1 ^ ^ run function kyoto:deco/ground
execute positioned ^ ^ ^ run function kyoto:deco/ground
execute positioned ^1 ^ ^ run function kyoto:deco/ground
execute positioned ^2 ^ ^ run function kyoto:deco/ground
execute positioned ^3 ^ ^ run function kyoto:deco/ground
execute positioned ^4 ^ ^ run function kyoto:deco/ground
execute positioned ^-4 ^ ^1 run function kyoto:deco/ground
execute positioned ^-4 ^ ^2 run function kyoto:deco/ground
execute positioned ^-4 ^ ^3 run function kyoto:deco/ground
execute positioned ^-4 ^ ^4 run function kyoto:deco/ground
execute positioned ^-4 ^ ^5 run function kyoto:deco/ground
execute positioned ^4 ^ ^1 run function kyoto:deco/ground
execute positioned ^4 ^ ^2 run function kyoto:deco/ground
execute positioned ^4 ^ ^3 run function kyoto:deco/ground
execute positioned ^4 ^ ^4 run function kyoto:deco/ground
execute positioned ^4 ^ ^5 run function kyoto:deco/ground
